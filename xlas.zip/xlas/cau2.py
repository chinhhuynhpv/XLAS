import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from mypackage import commonfunction  # Importing the commonfunction file

# Function to create a kernel of a given size and type (e.g., averaging)
def create_kernel(kernel_size):
    """Create a kernel of the specified size with uniform values."""
    return np.ones((kernel_size, kernel_size), np.int16) / (kernel_size ** 2)

# Function to perform convolution and add padding
def convolve_with_padding(image, kernel, padding):
    """Apply convolution with padding."""
    convolved_image = cv2.filter2D(image, -1, kernel)
    return cv2.copyMakeBorder(convolved_image, padding, padding, padding, padding, cv2.BORDER_CONSTANT)

# Function to apply stride to an image (downsample by stride factor)
def apply_stride(image, stride):
    """Apply stride by downsampling image."""
    return image[::stride, ::stride]

# Function to compute and display all images with different kernels and padding
def compute_convolutions_with_display(gray_image, output_dir):
    """Compute convolutions using different kernels and display the results."""
    # Create kernels
    kernel_3x3 = create_kernel(3)
    kernel_5x5 = create_kernel(5)
    kernel_7x7 = create_kernel(7)
    
    # Apply convolutions and padding
    I1 = convolve_with_padding(gray_image, kernel_3x3, padding=1)
    I2 = convolve_with_padding(gray_image, kernel_5x5, padding=2)
    I3 = convolve_with_padding(gray_image, kernel_7x7, padding=3)
    
    # Apply stride to I3 (stride=2)
    I3_stride = apply_stride(I3, stride=2)

    # Apply median filter to I3_stride
    I4 = cv2.medianBlur(I3_stride, 3)

    # Save the results
    save_images(I1, I2, I3_stride, I4, output_dir)

# Function to save the images in the output directory
def save_images(I1, I2, I3_stride, I4, output_dir):
    """Save the images in the specified directory."""
    # Save images to the output folder
    cv2.imwrite(os.path.join(output_dir, "I1_3x3_kernel_padding_1.png"), I1)
    cv2.imwrite(os.path.join(output_dir, "I2_5x5_kernel_padding_2.png"), I2)
    cv2.imwrite(os.path.join(output_dir, "I3_stride_2.png"), I3_stride)
    cv2.imwrite(os.path.join(output_dir, "I4_median_filter.png"), I4)

# Function to display images in a grid
def display_images(I1, I2, I3_stride, I4):
    """Display the images in a 2x2 grid."""
    plt.figure(figsize=(10, 10))

    plt.subplot(2, 2, 1)
    plt.imshow(I1, cmap='gray')
    plt.title("I1 - 3x3 Kernel with Padding=1")
    plt.axis('off')

    plt.subplot(2, 2, 2)
    plt.imshow(I2, cmap='gray')
    plt.title("I2 - 5x5 Kernel with Padding=2")
    plt.axis('off')

    plt.subplot(2, 2, 3)
    plt.imshow(I3_stride, cmap='gray')
    plt.title("I3 - 7x7 Kernel with Padding=3 and Stride=2")
    plt.axis('off')

    plt.subplot(2, 2, 4)
    plt.imshow(I4, cmap='gray')
    plt.title("I4 - Median Filter on I3")
    plt.axis('off')

    plt.tight_layout()
    plt.show()

# Main function to process multiple images
def main():
    # List of image paths to process
    image_paths = [
        'image1.jpg',  # Replace with actual paths to your images
        'image2.jpg',
        # 'image3.jpg',
        # 'image4.jpg',
        # 'image5.jpg',
        # 'image6.jpg',
        # 'image7.jpg',
        # 'image8.jpg',
        # 'image9.jpg',
        # 'image10.jpg'
    ]
    
    # Loop through each image
    for image_path in image_paths:
        # Get the base name of the image (without extension)
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        
        # Create an output folder for each image
        output_dir = os.path.join('result_cau2', image_name)
        os.makedirs(output_dir, exist_ok=True)

        # Load and convert the image to grayscale
        gray_image = commonfunction.load_and_convert_to_gray(image_path)
        
        # Compute convolutions and display/save results
        compute_convolutions_with_display(gray_image, output_dir)

# Run the main function
main()
