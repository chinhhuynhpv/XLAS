import cv2
import numpy as np
import os
from mypackage import commonfunction
import matplotlib.pyplot as plt


def create_kernel(kernel_size):
    return np.ones((kernel_size, kernel_size), np.int16) / (kernel_size ** 2)



def convolve_with_padding(image, kernel, padding):
    image = np.pad(image, pad_width=padding, mode='constant', constant_values=0)
    return deleteBorderMatrix(cv2.filter2D(image, -1, kernel))

def deleteBorderMatrix(image):
    return image[1:-1, 1:-1]

def apply_stride(image, stride):
    return image[::stride, ::stride]

def compute_convolutions_with_display(image_paths):
    
    kernel_3x3 = create_kernel(3)
    kernel_5x5 = create_kernel(5)
    kernel_7x7 = create_kernel(7)
    
    for image_path in image_paths:
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.join('result_cau2', image_name)
        os.makedirs(output_dir, exist_ok=True)
        gray_image = commonfunction.load_and_convert_to_gray(image_path)
        
        I1 = convolve_with_padding(gray_image, kernel_3x3, padding=1)
        I2 = convolve_with_padding(gray_image, kernel_5x5, padding=2)
        I3 = convolve_with_padding(gray_image, kernel_7x7, padding=3)
        I3_stride = apply_stride(I3, stride=2)

        # Apply median filter to I3_stride
        I4 = cv2.medianBlur(I3_stride, 3)

        # Save the results
        save_images(I1, I2, I3_stride, I4, output_dir)
        display_images(I1, I2,I3, I3_stride, I4)
        

def save_images(I1, I2, I3_stride, I4, output_dir):
    cv2.imwrite(os.path.join(output_dir, "I1_3x3_kernel_padding_1.png"), I1)
    cv2.imwrite(os.path.join(output_dir, "I2_5x5_kernel_padding_2.png"), I2)
    cv2.imwrite(os.path.join(output_dir, "I3_stride_2.png"), I3_stride)
    cv2.imwrite(os.path.join(output_dir, "I4_median_filter.png"), I4)

def display_images(I1, I2, I3, I3_stride, I4, padding=0):
    plt.figure(figsize=(10, 10))

    plt.subplot(2, 2, 1)
    plt.imshow(I1, cmap='gray')
    plt.title("I1 - 3x3 Kernel with Padding=1")
    plt.axis('off')

    plt.subplot(2, 2, 2)
    plt.imshow(I2, cmap='gray')
    plt.title("I2 - 5x5 Kernel with Padding=2")
    plt.axis('off')

    plt.subplot(2, 2, 3)
    plt.imshow(I3_stride, cmap='gray')
    plt.title("I3 - 7x7 Kernel with Padding=3 and Stride=2")
    plt.axis('off')

    plt.subplot(2, 2, 4)
    plt.imshow(I4, cmap='gray')
    plt.title("I4 - Median Filter on I3")
    plt.axis('off')

    plt.tight_layout()
    plt.show()
    
    # Create the figure with 1 row and 2 columns
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))  # 1 row, 2 columns

        # Display Histogram
    axes[0].hist(I2.ravel(), bins=256, color='red', alpha=0.7)
    axes[0].set_title(f'I2 ')
    axes[0].set_xlabel('Pixel Intensity')
    axes[0].set_ylabel('Frequency')
# Display Histogram
    axes[1].hist(I3_stride.ravel(), bins=256, color='blue', alpha=0.7)
    axes[1].set_title(f'I3 ')
    axes[1].set_xlabel('Pixel Intensity')
    axes[1].set_ylabel('Frequency')
    plt.tight_layout()

        # Show the plots
    plt.show()
    
    # Combine the histograms for LBP Image (combined and separate)
    I3_new = np.pad(I3, pad_width=3, mode='constant', constant_values=0)
    
    width = 870
    height = 870
    dim= (width, height)
    
    I3_res = cv2.resize(I3_new, dim)
    I_combined =  (I2 + I3_res)/2 # Combine the two 8-bit values
    
    # Combined Histogram
    plt.hist(I_combined.ravel(), bins=256, color='green', alpha=0.7)
    plt.title(f'Combined Histogram for')
    plt.xlabel('Combined I Value')
    plt.ylabel('Frequency')


    
    plt.tight_layout()

        # Show the plots
    plt.show()

# I = np.array([[5, 9, 1, 3, 4, 1, 5, 3, 1, 4],
#               [2, 9, 7, 5, 2, 1, 5, 5, 3, 2],
#               [6, 3, 6, 6, 3, 2, 7, 9, 4, 5],
#               [8, 5, 4, 8, 3, 3, 9, 9, 5, 4],
#               [4, 8, 4, 4, 2, 9, 4, 4, 2, 2]])
image_paths = ['image1.jpg']
compute_convolutions_with_display(image_paths)