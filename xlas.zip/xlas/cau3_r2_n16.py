import numpy as np
import matplotlib.pyplot as plt
from mypackage import commonfunction
import os


# Function to manually calculate LBP for a single pixel at (x, y) with radius=2, neighbors=16
def calculate_lbp_custom(image, x, y, radius=2, neighbors=16):
    center_value = image[x, y]
    
    # Define the neighbor order based on radius=2 and neighbors=16 (clockwise direction)
    neighbor_order = [
        (x-1, y+2), (x-2, y+2), (x-2, y+1),(x-2, y),
        (x-2, y-1), (x-2, y-2), (x-1, y-2),(x, y-2),
        (x+1, y-2), (x+2, y-2), (x+2, y-1), (x+2, y),
        (x+2, y+1), (x+2, y+2), (x+1, y+2), (x, y+2)
    ]
    
    # Get neighbors' values following the custom order
    neighbors_values = []
    for i in range(neighbors):
        nx, ny = neighbor_order[i]
        if 0 <= nx < image.shape[0] and 0 <= ny < image.shape[1]:
            neighbors_values.append(image[nx, ny])
        else:
            neighbors_values.append(0)  # Padding with 0 if out of bounds
    
    # Calculate binary pattern: 1 if neighbor >= center value, 0 otherwise
    binary_values = [1 if neighbor >= center_value else 0 for neighbor in neighbors_values]
    # print(f"bi current value {center_value}")
    # print(f"neigbor value {neighbors_values}")
    # print(f"bi position {x, y, binary_values}")
    # Convert binary values to a single 16-bit binary string (no reverse step needed)
    binary_string = ''.join(str(bit) for bit in binary_values)
    
    # Split the 16-bit binary string into two 8-bit strings
    binary_string_1 = binary_string[:8]
    binary_string_2 = binary_string[8:]
    
    # Convert both 8-bit binary strings to decimal
    lbp_value_1 = int(binary_string_1, 2)
    lbp_value_2 = int(binary_string_2, 2)
    
    return lbp_value_1, lbp_value_2

# Function to calculate LBP for the entire image
def calculate_lbp_image(image, radius=2, neighbors=16, padding=0):
    if padding > 0:
        image = np.pad(image, pad_width=padding, mode='constant', constant_values=0)
    
    lbp_image_1 = np.zeros_like(image)
    lbp_image_2 = np.zeros_like(image)
    
    # Iterate over all pixels (excluding edges)
    for i in range(2, image.shape[0] - 2):
        for j in range(2, image.shape[1] - 2):
            lbp_value_1, lbp_value_2 = calculate_lbp_custom(image, i, j, radius, neighbors)
            lbp_image_1[i, j] = lbp_value_1
            lbp_image_2[i, j] = lbp_value_2
    
    return lbp_image_1, lbp_image_2

# Function to process the images in image_paths, save results to the output directory
def process_images(image_paths, output_dir='result_cau3_r2_n16', radius=2, neighbors=16, padding=0):
    # Create the root output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for image_path in image_paths:
        print(f"Processing image: {image_path}")
        
        # Load and convert to grayscale
        image = commonfunction.load_and_convert_to_gray(image_path)
        
        if padding > 0:
            image = np.pad(image, pad_width=padding, mode='constant', constant_values=0)
            
        # Calculate LBP images
        lbp_image_1, lbp_image_2 = calculate_lbp_image(image, radius, neighbors, padding)
        
        # Create a subdirectory for this image
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        image_output_dir = os.path.join(output_dir, image_name)
        if not os.path.exists(image_output_dir):
            os.makedirs(image_output_dir)
        
        # Save LBP images
        plt.imsave(os.path.join(image_output_dir, 'lbp_image_1.png'), lbp_image_1, cmap='gray')
        plt.imsave(os.path.join(image_output_dir, 'lbp_image_2.png'), lbp_image_2, cmap='gray')
        
        # Combine the histograms for LBP Image (combined and separate)
        lbp_combined = (lbp_image_1 << 8) + lbp_image_2  # Combine the two 8-bit values
        
        # Save Histograms
        plt.figure(figsize=(10, 10))

        # Combined Histogram
        plt.subplot(1, 3, 1)
        plt.hist(lbp_combined.ravel(), bins=256, color='blue', alpha=0.7)
        plt.title(f'Combined Histogram for {image_name}')
        plt.xlabel('Combined LBP Value')
        plt.ylabel('Frequency')
        plt.savefig(os.path.join(image_output_dir, 'histogram_combined.png'))
        # Show the plots
        plt.show()
        plt.close()

        # Separate Histograms for each 8-bit part
        plt.subplot(1, 3, 2)
        plt.hist(lbp_image_2.ravel(), bins=256, color='blue', alpha=0.7, label='8-bit Part 2')
        plt.title(f'Separate Histograms for {image_name}')
        plt.xlabel('8-bit LBP Value')
        plt.ylabel('Frequency')
        plt.legend()
        plt.savefig(os.path.join(image_output_dir, 'histogram_separate.png'))
        plt.close()
        
        plt.subplot(1, 3, 3)
        plt.hist(lbp_image_1.ravel(), bins=256, color='red', alpha=0.7, label='8-bit Part 1')
        plt.title(f'Separate Histograms for {image_name}')
        plt.xlabel('8-bit LBP Value')
        plt.ylabel('Frequency')
        plt.legend()

        plt.show()
        plt.savefig(os.path.join(image_output_dir, 'histogram_separate.png'))
        plt.close()
        
        # Create the figure with 1 row and 2 columns
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))  # 1 row, 2 columns

        # Display Gray Image
    
        axes[0].hist(lbp_image_1.ravel(), bins=256, color='red', alpha=0.7)
        axes[0].set_title(f'I1 {image_path} padding {padding}')
        

        # Display Histogram
        axes[1].hist(lbp_image_2.ravel(), bins=256, color='blue', alpha=0.7)
        axes[1].set_title(f'I2  {image_path} padding {padding}')
        axes[1].set_xlabel('Pixel Intensity')
        axes[1].set_ylabel('Frequency')

        # Adjust layout for better spacing
        plt.tight_layout()

        # Show the plots
        plt.show()

        print(f"Results saved in {image_output_dir}")

# Example usage: Provide a list of image paths to the function
image_paths = ['image1.jpg']
process_images(image_paths, output_dir='result_cau3_r2_n16_p_0', radius=2, neighbors=16, padding=0)

process_images(image_paths, output_dir='result_cau3_r2_n16_p_1', radius=2, neighbors=16, padding=1)
