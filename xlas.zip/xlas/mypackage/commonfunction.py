import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
import csv

# Load and convert image to grayscale
def load_and_convert_to_gray(image_path):
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Image not found at the specified path: {image_path}")
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Generic function to display an image with a title
def display_image(image, title, cmap='gray', hide_axis=True, save_path=None):
    plt.imshow(image, cmap=cmap)
    plt.title(title)
    if hide_axis:
        plt.axis('off')
    
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')  # Save image if a path is provided
        plt.close()  # Close to free memory
    else:
        plt.show()  # Otherwise, just display the image

# Compute and plot the histogram of an image
def plot_histogram(image, title, output_dir):
    # Calculate histogram
    histogram = cv2.calcHist([image], [0], None, [256], [0, 256])

    # Flatten the histogram to a 1D array for easier writing to CSV (if needed later)
    histogram = histogram.flatten()

    # Create a figure and plot the histogram
    plt.figure(figsize=(8, 6))  # Set the figure size
    plt.title(title)  # Title for the histogram plot
    plt.xlabel('Pixel Intensity')  # Label for x-axis
    plt.ylabel('Frequency')  # Label for y-axis
    plt.plot(histogram, color='black')  # Plot the histogram in black color

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Save the histogram as an image
    histogram_image_path = os.path.join(output_dir, 'histogram.png')
    plt.savefig(histogram_image_path, bbox_inches='tight')  # Save it as an image file
    plt.close()  # Close the plot to free memory

    # Save the histogram to a CSV file
    csv_file_path = os.path.join(output_dir, 'histogram.csv')
    with open(csv_file_path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Pixel Intensity", "Frequency"])  # Write header
        for intensity, frequency in enumerate(histogram):
            writer.writerow([intensity, frequency])  # Write each row

    print(f"Histogram has been saved to {csv_file_path}")
    print(f"Histogram image saved to {histogram_image_path}")

# Perform histogram equalization and display the result
def equalize_histogram_and_show(gray_image, output_dir):
    equalized_image = cv2.equalizeHist(gray_image)
    equalized_image_path = os.path.join(output_dir, 'equalized_image.png')
    display_image(equalized_image, "Equalized Image", save_path=equalized_image_path)
    return equalized_image

# Clip the image's pixel values to a specified range and display the result
def clip_histogram_range(equalized_image, min_value=50, max_value=100, output_dir=None):
    clipped_image = np.clip(equalized_image, min_value, max_value)
    clipped_image_path = os.path.join(output_dir, f'clipped_image_{min_value}_{max_value}.png')
    display_image(clipped_image, f"Clipped Image (Range [{min_value}, {max_value}])", save_path=clipped_image_path)
    return clipped_image
