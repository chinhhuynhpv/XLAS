import os
from mypackage import commonfunction

def process_multiple_images(image_paths):
    for image_path in image_paths:
        
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        output_dir = os.path.join('result_cau1', image_name)
        os.makedirs(output_dir, exist_ok=True)
        
        # print(f"Processing image: {image_path}")
        
        gray_image = commonfunction.load_and_convert_to_gray(image_path)
        gray_image_path = os.path.join(output_dir, 'grayscale_image.png')
        commonfunction.display_image(gray_image, "Grayscale Image", save_path=gray_image_path)
        commonfunction.plot_histogram(gray_image, 'Histogram of Grayscale Image', output_dir)
        equalized_image = commonfunction.equalize_histogram_and_show(gray_image, output_dir)
        commonfunction.plot_histogram(equalized_image, 'Histogram of Equalized Image (H2)', output_dir)
        clipped_image = commonfunction.clip_histogram_range(equalized_image, 150, 200, output_dir)
        commonfunction.plot_histogram(clipped_image, 'Histogram of clipped_Image (H2)', output_dir)
        

image_paths = ['image1.jpg']

process_multiple_images(image_paths)