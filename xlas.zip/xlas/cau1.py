import os
from mypackage import commonfunction  # Importing the commonfunction file

# Main function to run the sequence of operations for multiple images
def process_multiple_images(image_paths):
    for image_path in image_paths:
        # Get the name of the image without extension
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        
        # Create a folder for the current image
        output_dir = os.path.join('result_cau1', image_name)
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"Processing image: {image_path}")
        
        # Load and convert image to grayscale
        gray_image = commonfunction.load_and_convert_to_gray(image_path)
        
        # Display and save the grayscale image
        gray_image_path = os.path.join(output_dir, 'grayscale_image.png')
        commonfunction.display_image(gray_image, "Grayscale Image", save_path=gray_image_path)
        
        # Plot and save the histogram of the grayscale image
        commonfunction.plot_histogram(gray_image, 'Histogram of Grayscale Image', output_dir)
        
        # Perform histogram equalization and save the result
        equalized_image = commonfunction.equalize_histogram_and_show(gray_image, output_dir)
        
        # Plot and save the histogram of the equalized image
        commonfunction.plot_histogram(equalized_image, 'Histogram of Equalized Image (H2)', output_dir)
        
        # Clip the histogram and save the result
        clipped_image = commonfunction.clip_histogram_range(equalized_image, 50, 100, output_dir)

# List of image paths to process
def main():
    image_paths = [
        'image1.jpg',  # Replace with actual paths
        'image2.jpg',  # Replace with actual paths
    ]
    process_multiple_images(image_paths)

main()
