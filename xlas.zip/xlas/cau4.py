import os
from cau1 import process_multiple_images as process_cau1
from cau2 import compute_convolutions_with_display as process_cau2
from cau3_r1_n8 import process_images as process_cau3_r1_n8
from cau3_r2_n16 import process_images as process_cau3_r2_n16
from cau3_r3_n24 import process_images as process_cau3_r3_n24

def main():
    # List of image paths
    image_paths = [
        'image1.jpg', 'image2.jpg', 'image3.png', 'image4.jpg', 'image5.jpg',
        'image6.jpg', 'image7.jpg', 'image8.jpg', 'image9.jpg', 'image10.jpg'
    ]
    
    process_cau1(image_paths)  # For Cau1 processing
    
    process_cau2(image_paths)  # For Cau2 processing
 
    process_cau3_r1_n8(image_paths, output_dir='result_cau3_r1_n8', radius=1, neighbors=8, padding=0)  # For Cau3 processing 
    process_cau3_r1_n8(image_paths, output_dir='result_cau3_r1_n8', radius=1, neighbors=8, padding=1)  # For Cau3 processing 
    process_cau3_r2_n16(image_paths, output_dir='result_cau3_r2_n16_p_0', radius=2, neighbors=16, padding=0)  # For Cau3 processing
    process_cau3_r2_n16(image_paths, output_dir='result_cau3_r2_n16_p_0', radius=2, neighbors=16, padding=1)  # For Cau3 processing
    process_cau3_r3_n24(image_paths, output_dir='result_cau3', radius=3, neighbors=24, padding=0)  # For Cau3 processing
    process_cau3_r3_n24(image_paths, output_dir='result_cau3', radius=3, neighbors=24, padding=1)  # For Cau3 processing

if __name__ == '__main__':
    main()
