import numpy as np
import cv2
import matplotlib.pyplot as plt
from skimage import feature, io
from skimage.exposure import equalize_hist
import os
from mypackage import commonfunction  # Import the commonfunction module


# Function to compute LBP with different radius (R) and padding
def compute_lbp(image, radius, neighbors, padding=0):
    lbp = feature.local_binary_pattern(image, neighbors, radius, method="uniform")
    
    if padding > 0:
        lbp = np.pad(lbp, pad_width=radius, mode='constant', constant_values=0)
    
    return lbp


# Function to display LBP images in a grid format
def display_lbp_images(images, titles, rows, cols, output_dir):
    fig, axes = plt.subplots(rows, cols, figsize=(12, 8))
    for i, ax in enumerate(axes.flat):
        ax.imshow(images[i], cmap='gray')
        ax.set_title(titles[i])
        ax.axis('off')
    
    # Save the grid of LBP images
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'lbp_images_grid.png'))
    plt.close()

# Function to plot histograms for each LBP image
def plot_histograms(lbp_image, neighbors, title, output_dir):
    plt.figure(figsize=(12, 6))
    
    # Combined histogram
    plt.subplot(1, 2, 1)
    plt.hist(lbp_image.ravel(), bins=np.arange(0, neighbors + 1), range=(0, neighbors), density=True)
    plt.title(f'Histogram Combined - {title}')
    plt.xlabel('LBP Value')
    plt.ylabel('Frequency')

    # Discrete histogram (for each 8-bit pattern)
    hist_discrete = [np.histogram(lbp_image.ravel(), bins=np.arange(i, i + 256), range=(i, i + 256))[0] for i in range(0, 50, 8)]
    plt.subplot(1, 2, 2)
    for h in hist_discrete:
        plt.plot(h)
    plt.title(f'Histogram Discrete - {title}')
    plt.xlabel('Pixel Value')
    plt.ylabel('Frequency')
    
    # Save the histogram plots
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'histogram_{title}.png'))
    plt.close()

# Function to equalize the histogram of LBP image
def equalize_lbp_hist(lbp_image):
    return equalize_hist(lbp_image)


# Main function to process LBP with different radii and padding
def process_lbp(image_path, output_dir):
    # 1. Read and convert the image to grayscale using commonfunction
    gray_image = commonfunction.load_and_convert_to_gray(image_path)  # Using the function from commonfunction

    # 2. Calculate LBP for different radii and padding values
    lbp_r1_p0 = compute_lbp(gray_image, radius=1, neighbors=8, padding=0)
    lbp_r2_p0 = compute_lbp(gray_image, radius=2, neighbors=16, padding=0)
    lbp_r3_p0 = compute_lbp(gray_image, radius=3, neighbors=24, padding=0)
    
    lbp_r1_p1 = compute_lbp(gray_image, radius=1, neighbors=8, padding=1)
    lbp_r2_p1 = compute_lbp(gray_image, radius=2, neighbors=16, padding=1)
    lbp_r3_p1 = compute_lbp(gray_image, radius=3, neighbors=24, padding=1)

    # 3. Display the LBP images
    lbp_images = [lbp_r1_p0, lbp_r2_p0, lbp_r3_p0, lbp_r1_p1, lbp_r2_p1, lbp_r3_p1]
    lbp_titles = ['LBP (R=1, Padding=0)', 'LBP (R=2, Padding=0)', 'LBP (R=3, Padding=0)',
                  'LBP (R=1, Padding=1)', 'LBP (R=2, Padding=1)', 'LBP (R=3, Padding=1)']
    display_lbp_images(lbp_images, lbp_titles, 2, 3, output_dir)

    # 4. Plot histograms for each LBP
    plot_histograms(lbp_r1_p0, 8, 'R=1, Padding=0', output_dir)
    plot_histograms(lbp_r2_p0, 16, 'R=2, Padding=0', output_dir)
    plot_histograms(lbp_r3_p0, 24, 'R=3, Padding=0', output_dir)
    
    plot_histograms(lbp_r1_p1, 8, 'R=1, Padding=1', output_dir)
    plot_histograms(lbp_r2_p1, 16, 'R=2, Padding=1', output_dir)
    plot_histograms(lbp_r3_p1, 24, 'R=3, Padding=1', output_dir)

    # 5. Equalize LBP histograms and display the results
    lbp_r1_p0_eq = equalize_lbp_hist(lbp_r1_p0)
    lbp_r2_p0_eq = equalize_lbp_hist(lbp_r2_p0)
    lbp_r3_p0_eq = equalize_lbp_hist(lbp_r3_p0)
    
    lbp_r1_p1_eq = equalize_lbp_hist(lbp_r1_p1)
    lbp_r2_p1_eq = equalize_lbp_hist(lbp_r2_p1)
    lbp_r3_p1_eq = equalize_lbp_hist(lbp_r3_p1)

    # Display equalized LBP images
    equalized_lbp_images = [lbp_r1_p0_eq, lbp_r2_p0_eq, lbp_r3_p0_eq, lbp_r1_p1_eq, lbp_r2_p1_eq, lbp_r3_p1_eq]
    equalized_lbp_titles = ['Equalized LBP (R=1, Padding=0)', 'Equalized LBP (R=2, Padding=0)', 
                             'Equalized LBP (R=3, Padding=0)', 'Equalized LBP (R=1, Padding=1)', 
                             'Equalized LBP (R=2, Padding=1)', 'Equalized LBP (R=3, Padding=1)']
    display_lbp_images(equalized_lbp_images, equalized_lbp_titles, 2, 3, output_dir)


# Main function to process multiple images
def main():
    # List of image paths to process
    image_paths = [
        'image1.jpg',  # Replace with actual paths to your images
        'image2.jpg'
    ]
    
    # Loop through each image
    for image_path in image_paths:
        # Get the base name of the image (without extension)
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        
        # Create an output folder for each image
        output_dir = os.path.join('result_cau3', image_name)
        os.makedirs(output_dir, exist_ok=True)

        # Process the image
        process_lbp(image_path, output_dir)

# Run the main function
main()
