import numpy as np
import matplotlib.pyplot as plt
from mypackage import commonfunction
import os

# Input image I0 (5x5 matrix)
# I0 = np.array([[5, 9, 1, 3, 4, 1, 5, 3, 1, 4],
#                [2, 9, 7, 5, 2, 1, 5, 5, 3, 2],
#                [6, 3, 6, 6, 3, 2, 7, 9, 4, 5],
#                [8, 5, 4, 8, 3, 3, 9, 9, 5, 4],
#                [4, 8, 4, 4, 2, 9, 4, 4, 2, 2],
#                [6, 3, 6, 6, 3, 2, 7, 9, 4, 5],
#                [8, 5, 4, 8, 3, 3, 9, 9, 5, 4]
#                ])

# Function to manually calculate LBP for a single pixel at (x, y)
def calculate_lbp_custom(image, x, y, radius=1, neighbors=8):
    center_value = image[x, y]
    
    neighbor_order = [
        (x-1, y+1), (x-1, y), (x-1, y-1), (x, y-1), 
        (x+1, y-1), (x+1, y), (x+1, y+1), (x, y+1)
    ]
    
    # Get neighbors' values following the custom order
    neighbors_values = []
    for i in range(neighbors):
        nx, ny = neighbor_order[i]
        if 0 <= nx < image.shape[0] and 0 <= ny < image.shape[1]:
            neighbors_values.append(image[nx, ny])
        else:
            neighbors_values.append(0)  # Padding with 0 if out of bounds
    
    # Calculate binary pattern: 1 if neighbor >= center value, 0 otherwise
    binary_values = [1 if neighbor >= center_value else 0 for neighbor in neighbors_values]
    
    # Reverse the order of the binary values to match the required order
    binary_values.reverse()  # Reverse the list of binary values
    
    # Convert binary pattern to decimal (LBP value)
    lbp_value = sum([binary_values[k] << k for k in range(neighbors)])
    
    return lbp_value

# Function to calculate LBP for the entire image
def calculate_lbp_image(image, radius=1, neighbors=8, padding=0):
    
    if padding > 0:
        image = np.pad(image, pad_width=padding, mode='constant', constant_values=0)
        
    lbp_image = np.zeros_like(image)
    
    # Iterate over all pixels (excluding edges)
    for i in range(radius, image.shape[0] - 1):
        for j in range(radius, image.shape[1] - 1):
            if(radius == 1):
                lbp_image[i, j] = calculate_lbp_custom(image, i, j, radius, neighbors)
    
    return lbp_image

def process_images(image_paths, output_dir='result_cau3_r1_n8', radius=1, neighbors=8, padding=0):
    # Create the root output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for image_path in image_paths:
        print(f"Processing image: {image_path}")
        
        # Load and convert to grayscale
        image = commonfunction.load_and_convert_to_gray(image_path)
        
        if padding > 0:
            image = np.pad(image, pad_width=padding, mode='constant', constant_values=0)
        
        # Calculate LBP images
        lbp_image = calculate_lbp_image(image, radius, neighbors, padding)
        
        # Create a subdirectory for this image
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        image_output_dir = os.path.join(output_dir, image_name)
        if not os.path.exists(image_output_dir):
            os.makedirs(image_output_dir)
        
        # Save LBP images
        plt.imsave(os.path.join(image_output_dir, 'lbp_image.png'), lbp_image, cmap='gray')
        
        # Create the figure with 1 row and 2 columns
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))  # 1 row, 2 columns

        # Display Gray Image
        axes[0].imshow(lbp_image, cmap='gray')
        axes[0].set_title(f'Gray Image {image_path} padding {padding}')
        axes[0].axis('off')  # Hide axis

        # Display Histogram
        axes[1].hist(lbp_image.ravel(), bins=256, color='blue', alpha=0.7)
        axes[1].set_title(f'Histogram of Gray Image {image_path} padding {padding}')
        axes[1].set_xlabel('Pixel Intensity')
        axes[1].set_ylabel('Frequency')

        # Adjust layout for better spacing
        plt.tight_layout()

        # Show the plots
        plt.show()

# Example usage: Provide a list of image paths to the function
image_paths = ['image1.jpg', 'image2.jpg', 'image3.png']
process_images(image_paths, output_dir='result_cau3_r1_n8_p_0', radius=1, neighbors=8, padding=0)

process_images(image_paths, output_dir='result_cau3_r1_n8_p_1', radius=1, neighbors=8, padding=1)